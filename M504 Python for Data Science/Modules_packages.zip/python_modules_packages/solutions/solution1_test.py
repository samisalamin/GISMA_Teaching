import string_utils

print(string_utils.reverse_string("hello"))
print(string_utils.is_palindrome("madam"))
