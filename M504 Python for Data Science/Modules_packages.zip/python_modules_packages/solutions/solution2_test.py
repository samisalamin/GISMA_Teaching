from converter import temperature, length

print(temperature.celsius_to_fahrenheit(0))
print(length.meters_to_feet(1))
