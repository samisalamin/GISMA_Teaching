import math
from math import pi

print(math.sqrt(16))
print(pi)
