def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
