import math

def area(radius):
    return math.pi * radius ** 2
