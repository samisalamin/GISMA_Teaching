def area(length, width):
    return length * width
