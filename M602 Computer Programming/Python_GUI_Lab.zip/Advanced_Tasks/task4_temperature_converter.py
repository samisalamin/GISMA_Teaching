import tkinter as tk

def convert():
    try:
        celsius = float(entry.get())
        fahrenheit = (celsius * 9/5) + 32
        result_label.config(text=f"{fahrenheit:.2f} °F")
    except ValueError:
        result_label.config(text="Invalid input")

window = tk.Tk()
window.title("Celsius to Fahrenheit")

entry = tk.Entry(window)
entry.pack()

convert_btn = tk.Button(window, text="Convert", command=convert)
convert_btn.pack()

result_label = tk.Label(window, text="")
result_label.pack()

window.mainloop()
