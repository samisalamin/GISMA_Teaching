import tkinter as tk

def calculate(op):
    try:
        num1 = float(entry1.get())
        num2 = float(entry2.get())
        if op == '+':
            result = num1 + num2
        elif op == '-':
            result = num1 - num2
        elif op == '*':
            result = num1 * num2
        elif op == '/':
            result = num1 / num2
        result_label.config(text=f"Result: {result}")
    except ValueError:
        result_label.config(text="Invalid input")
    except ZeroDivisionError:
        result_label.config(text="Cannot divide by zero")

window = tk.Tk()
window.title("Simple Calculator")

entry1 = tk.Entry(window)
entry1.pack()

entry2 = tk.Entry(window)
entry2.pack()

for op in ['+', '-', '*', '/']:
    btn = tk.Button(window, text=op, command=lambda o=op: calculate(o))
    btn.pack()

result_label = tk.Label(window, text="")
result_label.pack()

window.mainloop()
