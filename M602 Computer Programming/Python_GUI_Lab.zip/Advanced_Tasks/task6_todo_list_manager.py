import tkinter as tk

def add_task():
    task = entry.get()
    if task:
        listbox.insert(tk.END, task)
        entry.delete(0, tk.END)

def remove_task():
    selected = listbox.curselection()
    if selected:
        listbox.delete(selected)

def clear_tasks():
    listbox.delete(0, tk.END)

window = tk.Tk()
window.title("To-Do List")

entry = tk.Entry(window)
entry.pack()

add_btn = tk.Button(window, text="Add Task", command=add_task)
add_btn.pack()

remove_btn = tk.Button(window, text="Remove Selected", command=remove_task)
remove_btn.pack()

clear_btn = tk.Button(window, text="Clear All", command=clear_tasks)
clear_btn.pack()

listbox = tk.Listbox(window)
listbox.pack()

window.mainloop()
