import tkinter as tk

def set_red():
    window.config(bg="red")

def set_blue():
    window.config(bg="blue")

def show_message():
    msg = entry.get()
    label.config(text=msg)

window = tk.Tk()
window.title("Final GUI Lab")

btn_red = tk.Button(window, text="Red", command=set_red)
btn_red.pack()

btn_blue = tk.Button(window, text="Blue", command=set_blue)
btn_blue.pack()

entry = tk.Entry(window)
entry.pack()

btn_msg = tk.Button(window, text="Show Message", command=show_message)
btn_msg.pack()

label = tk.Label(window, text="")
label.pack()

window.mainloop()
