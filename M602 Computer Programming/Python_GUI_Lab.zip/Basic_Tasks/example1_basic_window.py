import tkinter as tk

window = tk.Tk()
window.title("Hello GUI")
label = tk.Label(window, text="Welcome to Tkinter!")
label.pack()
window.mainloop()
