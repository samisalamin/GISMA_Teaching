import tkinter as tk

def on_click():
    label.config(text="Button clicked!")

window = tk.Tk()
window.title("Button Example")

label = tk.Label(window, text="Click the button")
label.pack()

button = tk.Button(window, text="Click Me", command=on_click)
button.pack()

window.mainloop()
