import tkinter as tk

def show_message():
    msg = entry.get()
    label.config(text=msg)

window = tk.Tk()
window.title("Message Display")

entry = tk.Entry(window)
entry.pack()

button = tk.Button(window, text="Show Message", command=show_message)
button.pack()

label = tk.Label(window, text="")
label.pack()

window.mainloop()
