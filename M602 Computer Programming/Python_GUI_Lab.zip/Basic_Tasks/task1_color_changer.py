import tkinter as tk

def set_red():
    window.config(bg="red")

def set_blue():
    window.config(bg="blue")

window = tk.Tk()
window.title("Color Changer")

btn_red = tk.Button(window, text="Red", command=set_red)
btn_red.pack()

btn_blue = tk.Button(window, text="Blue", command=set_blue)
btn_blue.pack()

window.mainloop()
