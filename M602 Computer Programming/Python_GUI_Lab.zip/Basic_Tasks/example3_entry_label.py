import tkinter as tk

def update_label():
    name = entry.get()
    label.config(text=f"Hello, {name}!")

window = tk.Tk()
window.title("Entry Example")

entry = tk.Entry(window)
entry.pack()

button = tk.Button(window, text="Greet", command=update_label)
button.pack()

label = tk.Label(window, text="")
label.pack()

window.mainloop()
