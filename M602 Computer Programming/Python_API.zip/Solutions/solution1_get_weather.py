import requests

city = "London"
api_key = "your_api_key_here"  # Replace with your actual API key
url = "https://api.openweathermap.org/data/2.5/weather"

params = {"q": city, "appid": api_key}
response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()
    print(f"Weather in {city}: {data['weather'][0]['description']}")
else:
    print("Failed to retrieve weather data.")
