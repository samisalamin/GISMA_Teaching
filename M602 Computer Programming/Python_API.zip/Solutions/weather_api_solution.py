import requests

# Predefined city coordinates
city_coords = {
    "Berlin": (52.52, 13.41),
    "London": (51.51, -0.13),
    "New York": (40.71, -74.01),
    "Tokyo": (35.68, 139.69)
}

city = input("Enter a city (Berlin, London, New York, Tokyo): ")
if city in city_coords:
    lat, lon = city_coords[city]
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,wind_speed_10m"
    }

    response = requests.get(url, params=params)
    data = response.json()
    print("Current temperature:", data["current"]["temperature_2m"], "°C")
    print("Wind speed:", data["current"]["wind_speed_10m"], "km/h")
else:
    print("City not recognized.")
