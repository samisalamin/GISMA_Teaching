import requests

names = ["Alice", "Bob", "Charlie"]
for name in names:
    response = requests.get(f"https://api.agify.io?name={name}")
    if response.status_code == 200:
        data = response.json()
        print(f"{data['name']} is predicted to be {data['age']} years old.")
