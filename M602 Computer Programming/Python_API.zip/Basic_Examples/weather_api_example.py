import requests

url = "https://api.open-meteo.com/v1/forecast"
params = {
    "latitude": 52.52,
    "longitude": 13.41,
    "current": "temperature_2m,wind_speed_10m"
}

response = requests.get(url, params=params)
data = response.json()
print("Current temperature:", data["current"]["temperature_2m"], "°C")
print("Wind speed:", data["current"]["wind_speed_10m"], "km/h")
