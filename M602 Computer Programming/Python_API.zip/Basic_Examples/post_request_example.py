import requests

url = "https://httpbin.org/post"
payload = {"name": "Alice", "age": 30}
response = requests.post(url, json=payload)

if response.status_code == 200:
    print("POST request successful.")
    print(response.json())
else:
    print("POST request failed.")
