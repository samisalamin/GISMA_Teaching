import requests

response = requests.get("https://api.agify.io?name=michael")
if response.status_code == 200:
    data = response.json()
    print(f"Predicted age for 'michael': {data['age']}")
else:
    print("Request failed.")
