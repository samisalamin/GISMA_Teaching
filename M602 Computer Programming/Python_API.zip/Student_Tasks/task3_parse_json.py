# Task 3: Use the Agify API to predict the age of three different names.
# Parse and print the name and predicted age for each.
