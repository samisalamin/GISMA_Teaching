# Task 1: Use the OpenWeatherMap API to get current weather for a city.
# Hint: Use requests.get and pass parameters like city name and API key.
# Example endpoint: https://api.openweathermap.org/data/2.5/weather?q=London&appid=YOUR_API_KEY
