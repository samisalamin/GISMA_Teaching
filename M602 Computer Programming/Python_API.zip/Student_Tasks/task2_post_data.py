# Task 2: Send a POST request to https://httpbin.org/post with your name and favorite language.
# Print the response JSON.
